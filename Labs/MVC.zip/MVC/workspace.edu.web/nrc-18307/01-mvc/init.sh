npm init -y
npm install express
npm install nodemon typescript ts-node @types/node @types/express -D

tsc --init
