console.log('# Variables');

var oldVar = 'esta es una variable vieja';
console.log('oldVar => '+ oldVar);

oldVar = 20;
console.log('oldVar => '+ oldVar);

oldVar = true;
console.log('oldVar => '+ oldVar);

var num = 123, name = 'old', lastName = "last";
console.log(num);

