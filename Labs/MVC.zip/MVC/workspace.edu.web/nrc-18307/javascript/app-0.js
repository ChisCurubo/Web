/* comentario 
múltiples 
líneas  */

// comentario 1 línea

console.log('Hola mundo');
console.log([1,2,3,4,5]);
console.table([1,2,3,4,5]);
console.error("un error");
console.warn("una advertencia");
// console.clear();

console.time("time");
console.warn("contando...");
console.warn("contando...");
console.warn("contando...");
console.warn("contando...");
console.warn("contando...");
console.warn("contando...");
console.warn("contando...");
console.warn("contando...");
console.warn("contando...");
console.warn("contando...");
console.timeEnd("time");