import data, { sum } from './data.js';

const obj = await data();
console.log(obj);

console.log(sum(1, 2));