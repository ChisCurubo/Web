// punto entrada app  // BUILDER // Factory

import Server from "./express/server";

const server = new Server();
server.start();