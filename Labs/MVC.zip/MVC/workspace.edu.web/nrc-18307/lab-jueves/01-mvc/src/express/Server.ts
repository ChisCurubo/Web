import express, { Application } from "express"

export default class Server{
    private app : Application

    constructor(){
        this.app = express()
    }

    public start(){
        const HOST= process.env['HOST'] ??  'localhost';
        const PORT= process.env['PORT'] ??  '3000';
        const PROTOCOL= process.env['PROTOCOL'] ??  'http'

        this.app.listen(
            PORT,
            ()=> console.log(`Server Starting ${PROTOCOL}:://${HOST}:${PORT}`)
        )
        
    }
}