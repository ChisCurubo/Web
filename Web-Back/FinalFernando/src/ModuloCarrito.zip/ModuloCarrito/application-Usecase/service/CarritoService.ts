import CarritoServiceInterface from "../../Domain/interfaces/CarritoServiceInterface"
import { IProductoRepository }from "../../Domain/Port/Driven/IProductoRepository"
import { ICarritoRepository }from "../../Domain/Port/Driven/ICarritoRepository"
import { IProductoDetalle } from "../../Domain/Producto/interfaces/productoIntefaces";
import { IItemCarritoResumen } from "../../Domain/iItemCarrito/Interfaces/ItemCarritoInterfaces";
import { ICarritoCompleto, ITotalesCarrito } from "../../Domain/Carrito/interfaces/carritointerfaces";


export class CarritoService implements CarritoServiceInterface {
  constructor(
    private readonly productoRepository: IProductoRepository,
    private readonly carritoRepository: ICarritoRepository
  ) {}

  async agregarProductoAlCarrito(usuarioId: number, productoId: number, cantidad: number): Promise<void> {
    if (!usuarioId || usuarioId <= 0) throw new Error("El ID del usuario no es válido.");
    if (!productoId || productoId <= 0) throw new Error("El ID del producto no es válido.");
    if (!cantidad || cantidad <= 0) throw new Error("La cantidad debe ser mayor a 0.");

    const producto: IProductoDetalle | null = await this.productoRepository.findById(productoId);
    if (!producto) throw new Error("El producto no existe.");
    if (producto.stockProducto <= 0) throw new Error("El producto no está disponible.");
    if (producto.stockProducto < cantidad) throw new Error("No hay suficiente stock disponible.");

    await this.carritoRepository.addItem(usuarioId, productoId, cantidad);
  }

  async verMiCarritoId(idUsuario: number): Promise<IItemCarritoResumen[]> {
    const carrito = await this.carritoRepository.VerMiCarritoResumen(idUsuario);
    return carrito;
  }

  async verMiCarritoCompleto(idUsuario: number): Promise<ICarritoCompleto> {
    return await this.carritoRepository.verMiCarritoCompleto(idUsuario);
  }

  async calcularTotalesCarrito(idUsuario: number): Promise<ITotalesCarrito> {
    return await this.carritoRepository.calcularTotalesCarrito(idUsuario);
  }

  async calcularTotalesCarritoCompleto(idUsuario: number): Promise<ITotalesCarrito> {
    const carrito = await this.carritoRepository.calcularTotalesCarritoCompleto(idUsuario);
    return carrito;
  }

  async eliminarProductoDelCarrito(usuarioId: number, productoId: number): Promise<void> {
    await this.carritoRepository.removeItem(usuarioId, productoId);
  }

 
  async aumentarCantidadProducto(usuarioId: number, productoId: number): Promise<number> {
    if (!usuarioId || usuarioId <= 0) throw new Error("El ID del usuario no es válido.");
    if (!productoId || productoId <= 0) throw new Error("El ID del producto no es válido.");
  
    const producto: IProductoDetalle | null = await this.productoRepository.findById(productoId);
    if (!producto) throw new Error("El producto no existe.");
  
    const carrito = await this.carritoRepository.findByUsuarioId(usuarioId);
    
    // Usar el nuevo método getProductoId para la comparación
    const item = carrito.getItems().find(item => {
      try {
        return item.getProductoId() === productoId;
      } catch (error) {
        console.error("Error al obtener ID del producto para item:", error);
        return false;
      }
    });
    
    if (!item) throw new Error("El producto no está en el carrito.");
  
    if (producto.stockProducto < item.getCantidad() + 1) throw new Error("No hay suficiente stock disponible.");
  
    await this.carritoRepository.increaseItemQuantity(usuarioId, productoId);
    return item.getCantidad() + 1;
  }

  async disminuirCantidadProducto(usuarioId: number, productoId: number): Promise<number> {
    if (!usuarioId || usuarioId <= 0) {
      return 0; // O manejar de otra forma según tu lógica de negocio
    }
    
    if (!productoId || productoId <= 0) {
      return 0; // O manejar de otra forma según tu lógica de negocio
    }
    
    const carrito = await this.carritoRepository.findByUsuarioId(usuarioId);
    
    // Usar getProductoId en lugar de getProducto().getId()
    const item = carrito.getItems().find(item => {
      const itemProductoId = item.getProductoId ? item.getProductoId() : 
                            (item.getProducto() && typeof item.getProducto().getId === 'function' ? 
                             item.getProducto().getId() : undefined);
      return itemProductoId === productoId;
    });
    
    if (!item) {
      return 0; // O manejar de otra forma según tu lógica de negocio
    }
  
    if (item.getCantidad() <= 1) {
      await this.carritoRepository.removeItem(usuarioId, productoId);
      return 0;
    } else {
      await this.carritoRepository.decreaseItemQuantity(usuarioId, productoId);
      return item.getCantidad() - 1;
    }
  }
}
