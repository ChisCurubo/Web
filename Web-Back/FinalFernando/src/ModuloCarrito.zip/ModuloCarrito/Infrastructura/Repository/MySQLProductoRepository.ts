import { Connection } from "mysql2/promise";
import NullProducto from "../../Domain/Producto/NullProducto"
import { IProductoRepository } from "../../Domain/Port/Driven/IProductoRepository";
import AbstractProducto from "../../Domain/Producto/AbstractProducto";
import Producto from "../../Domain/Producto/Producto"
import { IProductoDetalle } from "../../Domain/Producto/interfaces/productoIntefaces";



export class MySQLProductoRepository implements IProductoRepository {
  constructor(private readonly connection: Connection) {}

  // Buscar producto por ID
  async findById(id: number): Promise<IProductoDetalle> {
    try {
        const [rows] = await this.connection.execute<any[]>(
            `SELECT 
                p.idProducto,
                p.nombreProducto,
                p.descripcionProducto,
                p.precioProducto,
                p.imgProducto,
                p.stockProducto,
                CASE 
                    WHEN p.descuento_id IS NOT NULL THEN 'Tiene promoción'
                    ELSE 'No tiene promoción'
                END AS promocion
            FROM Productos p
            WHERE p.idProducto = ?`,
            [id]
        );

        if (rows.length === 0) {
            throw new Error("Producto no encontrado");
        }

        return new Producto(rows[0]).toDetalle();
    } catch (error) {
        console.error("Error al buscar producto por ID:", error);
        throw error;
    }
}

  // Buscar producto por nombre
  async findByName(nombre: string): Promise<AbstractProducto> {
    try {
      const [rows]: any = await this.connection.execute(
        "CALL BuscarProductosFinal1(?)",
        [nombre]
      );

      if (rows.length === 0) {
        return new NullProducto();
      }

      return new Producto(rows[0]);
    } catch (error) {
      console.error("Error al buscar producto por nombre:", error);
      return new NullProducto();
    }
  }

  // Obtener todos los productos
  async findAll(): Promise<AbstractProducto[]> {
    try {
      const [rows]: any = await this.connection.execute(
        `SELECT p.idProducto, p.nombreProducto, p.descripcionProducto, 
                p.precioProducto, p.stockProducto, p.imgProducto AS imagenProducto, 
                p.categoria_id AS categoriaId, c.nombreCategoria AS categoriaNombre, 
                m.nombreMarca AS marcaNombre, t.nombreTalla AS tallaNombre, 
                CASE WHEN p.descuento_id IS NOT NULL THEN 'Sí' ELSE 'No' END AS enPromocion
         FROM Productos p
         JOIN Categoria c ON p.categoria_id = c.idCategoria
         JOIN Marcas m ON p.marca_id = m.idMarca
         JOIN Tallas t ON p.talla_id = t.idTalla`
      );

      return rows.map((producto: any) => new Producto(producto));
    } catch (error) {
      console.error("Error al obtener todos los productos:", error);
      return [new NullProducto];
    }
  }

// Buscar productos por rango de precios
async findByPriceRange(min: number, max: number): Promise<AbstractProducto[]> {
  try {
    const [rows]: any = await this.connection.execute(
      "CALL FiltrarProductosPorPrecio(?, ?)",
      [min, max]
    );

    return rows.map((producto: any) =>
      new Producto(producto).toVitrina()
    );
  } catch (error) {
    console.error("Error al buscar productos por rango de precios:", error);
    return [new NullProducto()];
  }
}

  // Buscar productos por término de búsqueda
  async search(termino: string): Promise<AbstractProducto[]> {
    try {
      const [rows]: any = await this.connection.execute(
        `SELECT p.idProducto, p.nombreProducto, p.descripcionProducto, 
                p.precioProducto, p.stockProducto, p.imgProducto AS imagenProducto, 
                p.categoria_id AS categoriaId, c.nombreCategoria AS categoriaNombre, 
                m.nombreMarca AS marcaNombre, t.nombreTalla AS tallaNombre, 
                CASE WHEN p.descuento_id IS NOT NULL THEN 'Sí' ELSE 'No' END AS enPromocion
         FROM Productos p
         JOIN Categoria c ON p.categoria_id = c.idCategoria
         JOIN Marcas m ON p.marca_id = m.idMarca
         JOIN Tallas t ON p.talla_id = t.idTalla
         WHERE p.nombreProducto LIKE ? OR p.descripcionProducto LIKE ?`,
        [`%${termino}%`, `%${termino}%`]
      );

      return rows.map((producto: any) => new Producto(producto));
    } catch (error) {
      console.error("Error al buscar productos por término:", error);
      return [new NullProducto()];
    }
  }

  async getShowcase(): Promise<AbstractProducto[]> {
    try {
      const [rows]: any = await this.connection.execute(
        `SELECT p.idProducto, p.nombreProducto, p.tallaProducto, p.precioProducto,
                p.stockProducto, p.imgProducto AS imagenProducto, c.nombreCategoria AS categoriaNombre,
                CASE WHEN p.descuento_id IS NOT NULL THEN 'Sí' ELSE 'No' END AS enPromocion
         FROM Productos p
         LEFT JOIN Categoria c ON p.categoria_id = c.idCategoria
         WHERE p.estadoProducto = TRUE
         ORDER BY p.nombreProducto ASC;`
      );
  
      return rows.map((producto: any) =>
        new Producto({
          idProducto: producto.idProducto,
          nombreProducto: producto.nombreProducto,
          descripcionProducto: producto.descripcionProducto,
          precioProducto: producto.precioProducto,
          stockProducto: producto.stockProducto,
          imagenProducto: producto.imagenProducto,
          categoriaId: producto.categoriaId,
          enPromocion: producto.enPromocion === 'Sí',
          categoriaNombre: producto.categoriaNombre,
          marcaNombre: producto.marcaNombre,
          tallaNombre: producto.tallaNombre,
        }).toVitrina()
      );
    } catch (error) {
      console.error("Error al obtener productos destacados:", error);
      return [new NullProducto()];
    }
  }
}
