export default interface RepositoryInterface {
 
}
