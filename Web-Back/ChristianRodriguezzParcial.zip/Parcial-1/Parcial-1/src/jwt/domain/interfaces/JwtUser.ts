export default interface JWTUser{
    ci:string,
    email:string,
    idRol:number
}