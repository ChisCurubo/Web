

export default interface CarritoInterfazApi {

}

export default interface ProductoInterfazApi{

}

export default interface UsuarioInterfazApi{
  
}

export default interface FavoritosInterfazApi{
  
}

export default interface RolesInterfazApi{
  
}

export default interface DescuentoInterfazApi{
  
}