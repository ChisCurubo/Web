
export interface Usuario {
  ci: string;
  nombreUsuario: string;
  apellidoUsuario: string;
  correoUsuario: string;
  contrasenaUsuario: string;
  estadoUsuario: boolean;
  rolUsuario: number ;
}
