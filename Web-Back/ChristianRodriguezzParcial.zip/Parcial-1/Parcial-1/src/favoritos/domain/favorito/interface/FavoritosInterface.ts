import AbstractProducto from "../../../../producto/domain/producto/AbstractTypes/AbstractProducto";



export interface Favoritos {
  idProducto: AbstractProducto[];
}
