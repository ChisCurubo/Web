

export interface MysqlUsuario {
    ci: string;
    nombreUsuario: string;
    apellidoUsuario: string;
    correoUsuario: string;
    contrasenaUsuario: string;
    estadoUsuario: boolean;
    rol: number; 
  }