
export interface MySQLFiltrarProducto {
    tallaProducto?: string ;
    precioProductoMin?: number;
    precioProductoMax?: number;
    categoria_id?: number ;
    descuento_id?: boolean;
  }