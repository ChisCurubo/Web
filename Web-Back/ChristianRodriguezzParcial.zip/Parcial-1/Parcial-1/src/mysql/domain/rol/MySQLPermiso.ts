export interface MysqlPermiso {
    idPermiso: number;
    nombrePermiso: string;
    tipo?: string;
    estadoPermiso?: boolean;
  }