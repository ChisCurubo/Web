export default interface MYSQLCarrito{
    idCarrito: number,
    estdoCarrito:boolean,
    usuario_id:string,
    
}