export default interface MYSQLItemCarrito{
    idItem: number,
    idProducto:number,
    cantidad:number
    idCarrito: number,
    subTotal:number,
}