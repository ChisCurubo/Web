export interface MysqlFavorito {
    idFavoritos?: number;
    usuario_id: string;
    producto_id: number;
  }