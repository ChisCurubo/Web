

export interface FiltrarProducto {
  tallaProducto?: string ;
  precioProductoMin?: number;
  precioProductoMax?: number;
  categoria_id?: number ;
  descuento_id?: boolean;
}