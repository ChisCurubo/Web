import RouterExpressInterface from '../../../express/domain/RouterExpressInterface'

export default interface CarritoRouterExpressInterface
  extends RouterExpressInterface {
    configureCarrito: () => void
  }
