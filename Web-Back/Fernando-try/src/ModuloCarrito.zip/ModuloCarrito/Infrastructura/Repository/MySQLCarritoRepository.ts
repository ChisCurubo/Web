
import { IProductoRepository } from '../../Domain/Port/Driven/IProductoRepository';
import { ICarritoRepository } from '../../Domain/Port/Driven/ICarritoRepository';
import AbstractCarrito from '../../Domain/Carrito/AbstractCarrito';
import Carrito from "../../Domain/Carrito/Carrito"
import NullCarrito from "../../Domain/Carrito/NullCarrito"
import AbstractItemCarrito from '../../Domain/iItemCarrito/ItemCarrito';
import ItemCarrito from '../../Domain/iItemCarrito/ItemCarrito';
import { Connection } from 'mysql2/promise';
import { ICarritoCompleto, ITotalesCarrito } from '../../Domain/Carrito/interfaces/carritointerfaces';
import {  IItemCarritoResumen, ItemCarritoInterface } from '../../Domain/iItemCarrito/Interfaces/ItemCarritoInterfaces';


export class MySQLCarritoRepository implements ICarritoRepository {
    constructor(
      private readonly connection: Connection,
      private readonly productoRepository: IProductoRepository
    ) {}
 

    async VerMiCarritoResumen(usuarioId: number): Promise<IItemCarritoResumen[]> {
      try {
        console.log("Usuario ID recibido:", usuarioId);
    
        const [result]: any = await this.connection.execute(
          'CALL VerMiCarrito(?);',
          [usuarioId]
        );
    
        console.log("Resultado de la consulta:", result);
    
        const rows = Array.isArray(result) ? result[0] : result;
    
        if (!rows || rows.length === 0) {
          console.log("El carrito está vacío para el usuario:", usuarioId);
          return [];
        }
    
        
    
        return rows.map((item: any) => {
          // Crear un objeto producto que implementa AbstractProducto
          const producto = {
            getId: () => item.idProducto,
            getNombre: () => item.nombreProducto,
            getTallaNombre: () => item.tallaProducto,
            getMarcaNombre: () => item.marca || 'N/A',
            getPrecio: () => parseFloat(item.precioProducto) 
          };
    
          // Crear un objeto que cumpla con la interfaz ItemCarritoInterface
          const itemData: ItemCarritoInterface = {
            idItemCarrito: item.idItemCarrito || 0,
            usuarioId: usuarioId,
            producto: producto,
            cantidad: item.cantidad
          };
          
          // Crear una instancia de ItemCarrito y usar su método toResumen()
          const itemCarrito = new ItemCarrito(itemData);
          return itemCarrito.toResumen();
        });
      } catch (error: any) {
        console.error('Error en verMiCarritoResumen:', error.message, error.stack);
        throw new Error(`Error al obtener el resumen del carrito: ${error.message}`);
      }
    }
  
    async findByUsuarioId(usuarioId: number): Promise<AbstractCarrito> {
      try {
        let carritoId: number;
    
        const [carritoRows] = await this.connection.execute(
          'SELECT idCarrito FROM Carrito WHERE usuario_id = ?',
          [usuarioId]
        );
    
        const carritos = carritoRows as any[];
    
        if (carritos.length === 0) {
          // Crear un nuevo carrito
          const [result] = await this.connection.execute(
            'INSERT INTO Carrito (usuario_id, totalCarrito) VALUES (?, 0)',
            [usuarioId]
          );
    
          const insertResult = result as any;
          carritoId = insertResult.insertId;
        } else {
          carritoId = carritos[0].idCarrito;
        }
    
        // Obtener los items del carrito
        const items = await this.getItems(carritoId);
    
        return new Carrito({
          idCarrito: carritoId,
          usuarioId: usuarioId,
          items: items as ItemCarrito[],
        });
      } catch (error) {
        console.error('Error al buscar carrito por ID de usuario:', error);
        return new NullCarrito();
      }
    }
  
   
    async addItem(usuarioId: number, productoId: number, cantidad: number): Promise<void> {
        try {
            await this.connection.execute(
                'CALL AgregarProductoAlCarrito(?, ?, ?);',
                [usuarioId, productoId, cantidad]
            );
        } catch (error) {
            console.error('Error al agregar item al carrito:', error);
            throw new Error('No se pudo agregar el producto al carrito');
        }
    }

  
    async removeItem(usuarioId: number, productoId: number): Promise<void> {
        try {
            await this.connection.execute(
                'CALL EliminarProductoDelCarrito(?, ?);',
                [usuarioId, productoId]
            );
        } catch (error) {
            console.error('Error al eliminar item del carrito:', error);
            throw new Error('No se pudo eliminar el producto del carrito');
        }
    }
  

  

    async increaseItemQuantity(usuarioId: number, productoId: number): Promise<number> {
        try {
            const [rows]: any = await this.connection.execute(
                'SELECT AumentarCantidadProductoCarrito(?, ?) AS cantidad;',
                [usuarioId, productoId]
            );
            return rows[0].cantidad;
        } catch (error) {
            console.error('Error al aumentar cantidad de producto:', error);
            throw new Error('No se pudo aumentar la cantidad del producto');
        }
    }
   
    async decreaseItemQuantity(usuarioId: number, productoId: number): Promise<number> {
        try {
            const [rows]: any = await this.connection.execute(
                'SELECT DisminuirCantidadProductoCarrito(?, ?) AS cantidad;',
                [usuarioId, productoId]
            );
            return rows[0].cantidad;
        } catch (error) {
            console.error('Error al disminuir cantidad de producto:', error);
            throw new Error('No se pudo disminuir la cantidad del producto');
        }
    }
  
    async getItems(carritoId: number): Promise<AbstractItemCarrito[]> {
      try {
        const [itemRows] = await this.connection.execute(
          `SELECT cp.idCarrito, cp.idProducto, cp.cantidad, 
                  p.nombreProducto, p.descripcionProducto, p.precioProducto, 
                  p.stockProducto, p.imgProducto, p.categoria_id, p.marcaProducto,
                  c.nombreCategoria
           FROM Carrito_Productos cp
           JOIN Productos p ON cp.idProducto = p.idProducto
           LEFT JOIN Categoria c ON p.categoria_id = c.idCategoria
           WHERE cp.idCarrito = ?`,
          [carritoId]
        );
        
        const items = itemRows as any[];
        
        return Promise.all(items.map(async (item) => {
          const producto = await this.productoRepository.findById(item.idProducto);
          return new ItemCarrito({
            idItemCarrito: carritoId,
            usuarioId: item.usuarioId, 
            producto: producto,
            cantidad: item.cantidad,
          });
        }));
      } catch (error) {
        console.error('Error al obtener items del carrito:', error);
        return [];
      }
    }

    async calcularTotalesCarrito(idUsuario: number): Promise<ITotalesCarrito> {
      try {
          const [rows]: any = await this.connection.execute(
              'CALL CalcularTotalesCarrito(?);',
              [idUsuario]
          );
          return rows[0][0] || {};
      } catch (error) {
          console.error('Error en calcularTotalesCarrito:', error);
          throw new Error('Error al calcular los totales del carrito');
      }
  }

  async calcularTotalesCarritoCompleto(idUsuario: number): Promise<ITotalesCarrito> {
      try {
          const [rows]: any = await this.connection.execute(
              'CALL CalcularTotalesCarritoCompleto(?);',
              [idUsuario]
          );
          return rows[0][0] || {};
      } catch (error) {
          console.error('Error en calcularTotalesCarritoCompleto:', error);
          throw new Error('Error al calcular los totales completos del carrito');
      }
  }

  async verMiCarritoCompleto(usuarioId: number): Promise<ICarritoCompleto> {
      try {
          const [rows]: any = await this.connection.execute(
              'CALL VerMiCarritoCompleto(?);',
              [usuarioId]
          );
          return rows || [];
      } catch (error) {
          console.error('Error en verMiCarritoCompleto:', error);
          throw new Error('Error al obtener el carrito completo');
      }
  }


 



  }
  