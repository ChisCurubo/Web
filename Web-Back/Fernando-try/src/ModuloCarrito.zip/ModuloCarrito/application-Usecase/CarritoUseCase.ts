import { ICarritoCompleto, ITotalesCarrito } from "../Domain/Carrito/interfaces/carritointerfaces";
import { IItemCarritoResumen } from "../Domain/iItemCarrito/Interfaces/ItemCarritoInterfaces";
import CarritoServiceInterface from "../Domain/interfaces/CarritoServiceInterface";
import CarritoUseCasePort from "../Domain/Port/Driver/CarritoUseCasePort";
import { IProductoDetalle } from "../Domain/Producto/interfaces/productoIntefaces";
import ProductoServiceInterface from "../Domain/interfaces/ProductoServiceInterface";
import NullCarrito from "../Domain/Carrito/NullCarrito"
import NullCarritoItem from "../Domain/iItemCarrito/NullItemCarrito"


export class CarritoUseCase implements CarritoUseCasePort {
    constructor(
      private readonly productoService: ProductoServiceInterface,
      private readonly carritoService: CarritoServiceInterface
    ) {}
  
    // 🛒 Agregar producto al carrito
    async agregarProductoAlCarrito(usuarioId: number, productoId: number, cantidad: number): Promise<void> {
      if (!usuarioId || usuarioId <= 0) {
        throw new Error("El ID del usuario no es válido.");
      }
      if (!productoId || productoId <= 0) {
        throw new Error("El ID del producto no es válido.");
      }
      if (!cantidad || cantidad <= 0) {
        throw new Error("La cantidad debe ser mayor a 0.");
      }
  
      const producto: IProductoDetalle | null = await this.productoService.obtenerProductoPorId(productoId);
      if (!producto) {
        throw new Error("El producto no existe.");
      }
      if (producto.stockProducto <= 0) {
        throw new Error("El producto no está disponible.");
      }
      if (producto.stockProducto < cantidad) {
        throw new Error("No hay suficiente stock disponible.");
      }
  
      await this.carritoService.agregarProductoAlCarrito(usuarioId, productoId, cantidad);
    }
  
    // 🛍 Ver carrito
    async verMiCarritoId(idUsuario: number): Promise<IItemCarritoResumen[]> {
      const carrito = await this.carritoService.verMiCarritoId(idUsuario);
      if (!carrito || carrito.length === 0) {
        return [new NullCarritoItem().toResumen()];
      }
      return carrito;
    }
  
    async verMiCarritoCompleto(idUsuario: number): Promise<ICarritoCompleto> {
      const carrito = await this.carritoService.verMiCarritoCompleto(idUsuario);
      if (!carrito) {
        return new NullCarrito().toCompleto();
      }
      return carrito;
    }
  
    // 🧮 Calcular totales
    async calcularTotalesCarrito(idUsuario: number): Promise<ITotalesCarrito> {
      const carrito = await this.carritoService.calcularTotalesCarrito(idUsuario);
      if (!carrito) {
        return new NullCarrito().toTotales();
      }
      return carrito;
    }
  
    async calcularTotalesCarritoCompleto(idUsuario: number): Promise<ITotalesCarrito> {
      const carrito = await this.carritoService.calcularTotalesCarritoCompleto(idUsuario);
      if (!carrito) {
        return new NullCarrito().toTotales();
      }
      return carrito;
    }
  
    // ❌ Eliminar producto del carrito
    async eliminarProductoDelCarrito(usuarioId: number, productoId: number): Promise<void> {
      await this.carritoService.eliminarProductoDelCarrito(usuarioId, productoId);
    }
  
    // ➕ Aumentar cantidad de un producto
    async aumentarCantidadProducto(usuarioId: number, productoId: number): Promise<number> {
      if (!usuarioId || usuarioId <= 0) {
        throw new Error("El ID del usuario no es válido.");
      }
      if (!productoId || productoId <= 0) {
        throw new Error("El ID del producto no es válido.");
      }
  
      const producto: IProductoDetalle | null = await this.productoService.obtenerProductoPorId(productoId);
      if (!producto) {
        throw new Error("El producto no existe.");
      }
  
      const cantidad = await this.carritoService.aumentarCantidadProducto(usuarioId, productoId);
      if (!cantidad) {
        return 0;
      }
      return cantidad;
    }
  
    // ➖ Disminuir cantidad de un producto
    async disminuirCantidadProducto(usuarioId: number, productoId: number): Promise<number> {
      const cantidad = await this.carritoService.disminuirCantidadProducto(usuarioId, productoId);
      if (!cantidad) {
        return 0;
      }
      return cantidad;
    }
  }
  