export interface Tablero{
    tablero: string [][]
    status: boolean
}