import { Tablero } from "../types/CuatroRaya";


export default class CuatroRayaModel{
    private tableroJuego : Tablero = {
        tablero: [[]],
        status: false
    }

    public initGame (): Tablero{
      this.tableroJuego.tablero = new Array(7).fill(new Array(6).fill(''));
       
        return this.tableroJuego;
    }

    public playGame(ficha: string, x: number, y: number): Tablero {
        if(this.tableroJuego.tablero[x][y] === ''){
            this.tableroJuego.tablero[x][y] = ficha;
            this.tableroJuego.status = this.checkWin()
            return this.tableroJuego
        }
        
    }

    private checkWin(): boolean{
        for (let f = 0; f < this.tableroJuego.tablero.length; f++) {
            for (let c = 0; c < this.tableroJuego.tablero[f].length; c++) {
                // metodo para checkear si gano vertical ,horizontal  y diagonal
            }
            
        }
    }
}