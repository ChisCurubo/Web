

const res = await fetch('http://localhost:1803/api/v1.0/4raya/init', {
    method: "GET",
    headers: {
        "Content-Type": "application/json"
    }
    
});
