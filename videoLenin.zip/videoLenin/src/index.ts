import Index from './index/Index.js'




const index = new Index()
index.init()


  