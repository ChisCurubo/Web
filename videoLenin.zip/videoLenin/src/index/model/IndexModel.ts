export default class IndexModel {
  readonly init = () => {
    console.log('IndexModel.init()')
  }
}
