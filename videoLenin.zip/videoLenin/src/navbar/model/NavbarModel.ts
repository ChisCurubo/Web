

export default class NavbarModel  {
  readonly init = () => {
    console.log('NavbarModel.init()')
  }
}
