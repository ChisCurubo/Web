export default {
    price: 0,
    title:"not found",
    year:1999,
    score:0,
    cast:[],
    genres:[],
    extract: "not found",
    thumbnail:"not found"
}